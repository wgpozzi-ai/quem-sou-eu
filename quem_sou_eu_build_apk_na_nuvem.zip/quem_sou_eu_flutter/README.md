# Quem Sou Eu? — MVP Flutter

Aplicativo Android de jogo presencial em equipes, gratuito e sem anúncios.

## Requisitos

- Flutter SDK instalado
- Android Studio ou Android SDK
- Um emulador Android ou celular com depuração USB habilitada

## Executar

Na pasta do projeto:

```bash
flutter pub get
flutter run
```

## Gerar APK de teste

```bash
flutter build apk --release
```

O APK costuma ser criado em `build/app/outputs/flutter-apk/app-release.apk`.

## O que já está implementado

- Tela inicial
- Configuração de 2 a 4 equipes
- Nome personalizado das equipes
- Seleção de categorias
- Duração da rodada de 30 a 120 segundos
- 1 a 5 rodadas por equipe
- Sorteio de cartas locais
- Cronômetro
- Acerto vale 1 ponto
- Passes ilimitados e sem penalidade
- Placar final e detecção de empate
- Sem conta, servidor, anúncios ou necessidade de internet

## Limitações conhecidas do MVP

- A tela exibe a carta no próprio celular; o uso com o aparelho na testa deve ser validado em aparelho real e pode precisar de ajustes de layout/orientação.
- Os botões de acerto e passe são manuais. Sensores de inclinação ainda não foram implementados.
- A estrutura inicial não inclui o modo de perguntas automáticas; ele é a próxima funcionalidade a implementar.
- O catálogo é pequeno e usa nomes/descritivos para prototipagem. Antes de publicar, revisar direitos de uso e ampliar o conteúdo.
- Não há persistência de estatísticas após fechar o aplicativo.
- Recomenda-se executar `flutter analyze` e `flutter test` antes de distribuir.

## Próximas melhorias

1. Implementar testes unitários para pontuação, troca de equipe e fim de partida.
2. Ajustar interface para orientação horizontal e modo tela cheia.
3. Implementar sensores de inclinação com um pacote Flutter adequado, mantendo os botões como alternativa acessível.
4. Implementar perguntas automáticas a partir de atributos estruturados.
5. Ampliar e revisar o catálogo.
6. Gerar AAB e preparar os materiais de publicação da Google Play.
