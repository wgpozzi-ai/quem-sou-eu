import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  runApp(const QuemSouEuApp());
}

const navy = Color(0xFF172554);
const teal = Color(0xFF0D9488);
const gold = Color(0xFFFDE68A);

class Character {
  const Character({
    required this.name,
    required this.category,
    required this.clue,
    required this.tags,
  });

  final String name;
  final String category;
  final String clue;
  final List<String> tags;

  factory Character.fromJson(Map<String, dynamic> json) => Character(
        name: json['name'] as String,
        category: json['category'] as String,
        clue: json['clue'] as String,
        tags: (json['tags'] as List<dynamic>).cast<String>(),
      );
}

class GameTeam {
  GameTeam(this.name) : score = 0;
  String name;
  int score;
}

class CharacterRepository {
  Future<List<Character>> load() async {
    final raw = await rootBundle.loadString('assets/data/characters.json');
    final decoded = jsonDecode(raw) as List<dynamic>;
    return decoded
        .map((item) => Character.fromJson(item as Map<String, dynamic>))
        .toList();
  }
}

class QuemSouEuApp extends StatelessWidget {
  const QuemSouEuApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quem Sou Eu?',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: teal,
          primary: teal,
          secondary: gold,
          surface: const Color(0xFFF7F8FC),
        ),
        scaffoldBackgroundColor: const Color(0xFFF7F8FC),
        appBarTheme: const AppBarTheme(
          backgroundColor: navy,
          foregroundColor: Colors.white,
          centerTitle: true,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            minimumSize: const Size(48, 52),
            textStyle: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [navy, Color(0xFF1E3A8A), teal],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(26),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Spacer(),
                const Icon(Icons.psychology_alt_rounded,
                    size: 86, color: gold),
                const SizedBox(height: 20),
                const Text(
                  'QUEM SOU EU?',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 34,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 10),
                const Text(
                  'Sua turma. Seus personagens. Sua diversão.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white70, fontSize: 16),
                ),
                const SizedBox(height: 34),
                FilledButton.icon(
                  style: FilledButton.styleFrom(
                    backgroundColor: gold,
                    foregroundColor: navy,
                  ),
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const SetupScreen()),
                  ),
                  icon: const Icon(Icons.play_arrow_rounded),
                  label: const Text('JOGAR'),
                ),
                const SizedBox(height: 12),
                const Text(
                  'Gratuito • Sem anúncios • Funciona offline',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white70, fontSize: 12),
                ),
                const Spacer(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class SetupScreen extends StatefulWidget {
  const SetupScreen({super.key});

  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  final _teamControllers = [
    TextEditingController(text: 'Equipe Azul'),
    TextEditingController(text: 'Equipe Amarela'),
  ];
  int _teamCount = 2;
  int _seconds = 60;
  int _rounds = 2;
  final Set<String> _categories = {'Anime', 'Filmes e séries'};
  final List<String> _allCategories = const [
    'Anime',
    'Filmes e séries',
    'Futebol',
    'Animais',
    'Profissões e objetos',
  ];

  @override
  void dispose() {
    for (final controller in _teamControllers) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Configurar partida')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text('Equipes', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          SegmentedButton<int>(
            segments: const [
              ButtonSegment(value: 2, label: Text('2 equipes')),
              ButtonSegment(value: 3, label: Text('3 equipes')),
              ButtonSegment(value: 4, label: Text('4 equipes')),
            ],
            selected: {_teamCount},
            onSelectionChanged: (values) =>
                setState(() => _teamCount = values.first),
          ),
          const SizedBox(height: 12),
          for (var i = 0; i < _teamCount; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: TextField(
                controller: _teamControllers[i],
                decoration: InputDecoration(
                  labelText: 'Nome da equipe ${i + 1}',
                  border: const OutlineInputBorder(),
                  prefixIcon: const Icon(Icons.groups_rounded),
                ),
              ),
            ),
          const Divider(height: 30),
          Text('Categorias', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 6),
          const Text('Selecione uma ou mais categorias.'),
          ..._allCategories.map(
            (category) => CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(category),
              value: _categories.contains(category),
              onChanged: (selected) => setState(() {
                if (selected == true) {
                  _categories.add(category);
                } else if (_categories.length > 1) {
                  _categories.remove(category);
                }
              }),
            ),
          ),
          const Divider(height: 30),
          Text('Tempo por rodada: $_seconds segundos',
              style: Theme.of(context).textTheme.titleMedium),
          Slider(
            value: _seconds.toDouble(),
            min: 30,
            max: 120,
            divisions: 6,
            label: '$_seconds s',
            onChanged: (value) =>
                setState(() => _seconds = value.round()),
          ),
          const SizedBox(height: 8),
          Text('Rodadas por equipe: $_rounds',
              style: Theme.of(context).textTheme.titleMedium),
          Slider(
            value: _rounds.toDouble(),
            min: 1,
            max: 5,
            divisions: 4,
            label: '$_rounds',
            onChanged: (value) => setState(() => _rounds = value.round()),
          ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: _startGame,
            icon: const Icon(Icons.sports_esports),
            label: const Text('Começar partida'),
          ),
        ],
      ),
    );
  }

  void _startGame() {
    if (_categories.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Selecione ao menos uma categoria.')),
      );
      return;
    }
    final names = _teamControllers
        .take(_teamCount)
        .map((controller) => controller.text.trim())
        .toList();
    for (var i = 0; i < names.length; i++) {
      if (names[i].isEmpty) names[i] = 'Equipe ${i + 1}';
    }
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => GameScreen(
          teams: names.map(GameTeam.new).toList(),
          categories: _categories.toSet(),
          secondsPerTurn: _seconds,
          roundsPerTeam: _rounds,
        ),
      ),
    );
  }
}

class GameScreen extends StatefulWidget {
  const GameScreen({
    required this.teams,
    required this.categories,
    required this.secondsPerTurn,
    required this.roundsPerTeam,
    super.key,
  });

  final List<GameTeam> teams;
  final Set<String> categories;
  final int secondsPerTurn;
  final int roundsPerTeam;

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  List<Character> _deck = [];
  Character? _current;
  Timer? _timer;
  int _teamIndex = 0;
  int _turnNumber = 0;
  int _remaining = 60;
  int _totalTurns = 0;
  int _cardsResolved = 0;
  int _correctThisTurn = 0;
  bool _loading = true;
  bool _finished = false;
  bool _turnActive = false;
  final Random _random = Random();

  int get _maxTurns => widget.teams.length * widget.roundsPerTeam;
  GameTeam get _currentTeam => widget.teams[_teamIndex];

  @override
  void initState() {
    super.initState();
    _remaining = widget.secondsPerTurn;
    _loadCharacters();
  }

  Future<void> _loadCharacters() async {
    try {
      final all = await CharacterRepository().load();
      _deck = all.where((c) => widget.categories.contains(c.category)).toList()
        ..shuffle(_random);
      if (!mounted) return;
      setState(() {
        _loading = false;
        if (_deck.isEmpty) {
          _finished = true;
        } else {
          _current = _deck.removeLast();
        }
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _finished = true;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Não foi possível carregar os personagens.')),
      );
    }
  }

  void _startTurn() {
    if (_finished || _current == null) return;
    setState(() {
      _remaining = widget.secondsPerTurn;
      _correctThisTurn = 0;
      _turnActive = true;
    });
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) return;
      if (_remaining <= 1) {
        timer.cancel();
        setState(() {
          _remaining = 0;
          _turnActive = false;
        });
        _finishTurn();
      } else {
        setState(() => _remaining--);
      }
    });
  }

  void _correct() {
    if (!_turnActive || _current == null) return;
    setState(() {
      _currentTeam.score++;
      _correctThisTurn++;
      _cardsResolved++;
      _nextCharacter();
    });
  }

  void _pass() {
    if (!_turnActive || _current == null) return;
    setState(() {
      _cardsResolved++;
      _nextCharacter();
    });
  }

  void _nextCharacter() {
    if (_deck.isEmpty) {
      _deck = CharacterRepositoryFallback.characters
          .where((c) => widget.categories.contains(c.category))
          .toList()
        ..shuffle(_random);
    }
    if (_deck.isNotEmpty) _current = _deck.removeLast();
  }

  void _finishTurn() {
    _timer?.cancel();
    if (!mounted) return;
    setState(() => _turnActive = false);
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        title: Text('${_currentTeam.name}: fim da rodada!'),
        content: Text('Acertos nesta rodada: $_correctThisTurn.'),
        actions: [
          FilledButton(
            onPressed: () {
              Navigator.of(dialogContext).pop();
              _advanceTurn();
            },
            child: const Text('Próxima equipe'),
          ),
        ],
      ),
    );
  }

  void _advanceTurn() {
    if (_turnNumber + 1 >= _maxTurns) {
      setState(() => _finished = true);
      return;
    }
    setState(() {
      _turnNumber++;
      _teamIndex = (_teamIndex + 1) % widget.teams.length;
      _remaining = widget.secondsPerTurn;
      _correctThisTurn = 0;
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_finished) return _buildResults();
    if (_current == null) {
      return const Scaffold(body: Center(child: Text('Sem personagens nessa categoria.')));
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(_currentTeam.name),
        actions: [
          IconButton(
            tooltip: 'Encerrar partida',
            onPressed: _confirmExit,
            icon: const Icon(Icons.close),
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(child: Text('Rodada ${_turnNumber + 1} de $_maxTurns')),
                  Text('Placar: ${_currentTeam.score}',
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                ],
              ),
              const SizedBox(height: 12),
              Expanded(
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: navy,
                    borderRadius: BorderRadius.circular(24),
                  ),
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.psychology_alt_rounded,
                          color: gold, size: 42),
                      const SizedBox(height: 10),
                      Text(
                        _current!.name,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 36,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        _current!.category,
                        style: const TextStyle(color: Colors.white70),
                      ),
                      const SizedBox(height: 18),
                      Text(
                        _turnActive
                            ? 'Dê dicas! A equipe precisa adivinhar.'
                            : 'Coloque o celular na testa, com a tela voltada para os amigos, e inicie a rodada.',
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.white),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Text(
                _turnActive ? '$_remaining s' : '$_remaining s',
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.w900,
                  color: _remaining <= 10 && _turnActive
                      ? Colors.red
                      : navy,
                ),
              ),
              const SizedBox(height: 10),
              if (!_turnActive)
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: _startTurn,
                    icon: const Icon(Icons.play_arrow),
                    label: const Text('Iniciar cronômetro'),
                  ),
                )
              else
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: _pass,
                        icon: const Icon(Icons.skip_next),
                        label: const Text('Passar'),
                        style: FilledButton.styleFrom(
                          backgroundColor: Colors.blueGrey,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: _correct,
                        icon: const Icon(Icons.check),
                        label: const Text('Acertou!'),
                      ),
                    ),
                  ],
                ),
              const SizedBox(height: 8),
              Text(
                'Passes ilimitados • Acerto = 1 ponto',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildResults() {
    final sorted = [...widget.teams]
      ..sort((a, b) => b.score.compareTo(a.score));
    final tied = sorted.length > 1 && sorted[0].score == sorted[1].score;
    return Scaffold(
      appBar: AppBar(title: const Text('Resultado da partida')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            const Spacer(),
            Icon(
              tied ? Icons.handshake_rounded : Icons.emoji_events_rounded,
              size: 84,
              color: gold,
            ),
            const SizedBox(height: 14),
            Text(
              tied ? 'Deu empate!' : 'Vitória!',
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.w900,
                    color: navy,
                  ),
            ),
            const SizedBox(height: 20),
            ...sorted.map(
              (team) => Card(
                child: ListTile(
                  leading: const Icon(Icons.groups_rounded, color: teal),
                  title: Text(team.name),
                  trailing: Text(
                    '${team.score} pts',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () => Navigator.of(context).popUntil((route) => route.isFirst),
                icon: const Icon(Icons.home),
                label: const Text('Voltar ao início'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _confirmExit() {
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Encerrar partida?'),
        content: const Text('O placar desta partida será descartado.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Continuar jogando'),
          ),
          FilledButton(
            onPressed: () {
              Navigator.of(dialogContext).pop();
              Navigator.of(context).popUntil((route) => route.isFirst);
            },
            child: const Text('Encerrar'),
          ),
        ],
      ),
    );
  }
}

// Cópia de segurança do catálogo para permitir que a partida continue
// quando todas as cartas da primeira embaralhada tiverem sido usadas.
class CharacterRepositoryFallback {
  static const characters = <Character>[
    Character(name: 'Luffy', category: 'Anime', clue: 'Pirata de One Piece.', tags: ['anime']),
    Character(name: 'Naruto', category: 'Anime', clue: 'Ninja que sonha em ser Hokage.', tags: ['anime']),
    Character(name: 'Goku', category: 'Anime', clue: 'Guerreiro Saiyajin.', tags: ['anime']),
    Character(name: 'Homem-Aranha', category: 'Filmes e séries', clue: 'Herói que lança teias.', tags: ['heroi']),
    Character(name: 'Harry Potter', category: 'Filmes e séries', clue: 'Bruxo de Hogwarts.', tags: ['bruxo']),
    Character(name: 'Shrek', category: 'Filmes e séries', clue: 'Ogro do pântano.', tags: ['ogro']),
    Character(name: 'Neymar', category: 'Futebol', clue: 'Jogador brasileiro.', tags: ['futebol']),
    Character(name: 'Messi', category: 'Futebol', clue: 'Craque argentino.', tags: ['futebol']),
    Character(name: 'Leão', category: 'Animais', clue: 'Grande felino.', tags: ['animal']),
    Character(name: 'Golfinho', category: 'Animais', clue: 'Mamífero marinho.', tags: ['animal']),
    Character(name: 'Astronauta', category: 'Profissões e objetos', clue: 'Trabalha no espaço.', tags: ['profissao']),
    Character(name: 'Bicicleta', category: 'Profissões e objetos', clue: 'Veículo de duas rodas.', tags: ['objeto']),
  ];
}
